import type { NextConfig } from "next";

const supabaseHost = (() => {
  try {
    return new URL(
      process.env. ?? "https://noctofhzvbynvkvnpsol.supabase.co",
    ).hostname;
  } catch {
    return "example.supabase.co";
  }
})();

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: supabaseHost,
        pathname: "/storage/v1/object/public/**",
      },
      {
        protocol: "https",
        hostname: "images.unsplash.com",
        pathname: "/**",
      },
    ],
  },
};

export default nextConfig;
