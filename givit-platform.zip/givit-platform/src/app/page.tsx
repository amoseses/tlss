import Link from "next/link";
import { Sparkles, ArrowRight, Gift, Star, Zap } from "lucide-react";

import { ProductCard } from "@/components/product/product-card";
import { getHomePageSections } from "@/lib/data/home-catalog";

export default async function HomePage() {
  const { featured, bestSellers, newArrivals, ratings } = await getHomePageSections();

  return (
    <div className="pb-12">
      {/* Hero */}
      <section className="relative overflow-hidden bg-givit-ink">
        {/* Decorative orb */}
        <div className="pointer-events-none absolute -top-32 right-0 h-[600px] w-[600px] rounded-full bg-givit-ember/10 blur-3xl" />
        <div className="pointer-events-none absolute bottom-0 left-1/4 h-[300px] w-[300px] rounded-full bg-givit-coral/10 blur-3xl" />

        <div className="container relative py-16 md:py-24 lg:py-28">
          <div className="max-w-3xl">
            {/* Tag */}
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-givit-coral/30 bg-givit-ember/10 px-3 py-1.5 text-xs font-semibold text-givit-coral">
              <Sparkles className="h-3 w-3" />
              AI-Powered Gift Intelligence
            </div>

            <h1 className="font-serif text-4xl font-bold leading-tight text-white md:text-5xl lg:text-6xl">
              Tell us who it&apos;s for.
              <br />
              <span className="italic text-givit-coral">We&apos;ll find the perfect gift.</span>
            </h1>

            <p className="mt-5 max-w-xl text-base text-white/60 md:text-lg">
              Our AI understands relationships, occasions, and budgets.
              Stop guessing — start gifting with confidence.
            </p>

            {/* CTA row */}
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/gift"
                className="group inline-flex items-center gap-2 rounded-full bg-givit-ember px-6 py-3 text-sm font-semibold text-white transition-all hover:bg-givit-ember-hover hover:shadow-lg hover:shadow-givit-ember/20"
              >
                <Sparkles className="h-4 w-4" />
                Find a Gift with AI
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </Link>
              <Link
                href="/products"
                className="inline-flex items-center gap-2 rounded-full border border-white/20 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-white/10"
              >
                Browse All Products
              </Link>
            </div>

            {/* Social proof */}
            <div className="mt-8 flex flex-wrap items-center gap-5 text-xs text-white/40">
              <div className="flex items-center gap-1.5">
                <Zap className="h-3 w-3 text-givit-coral" />
                <span>Results in 10 seconds</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Star className="h-3 w-3 text-givit-coral" />
                <span>Curated by AI + humans</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Gift className="h-3 w-3 text-givit-coral" />
                <span>Any budget, any occasion</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="border-b border-border/50 bg-givit-sand/40">
        <div className="container py-10">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
            {[
              { icon: "💬", step: "01", title: "Tell us about them", desc: "Relationship, interests, occasion, budget — plain English works." },
              { icon: "🧠", step: "02", title: "AI finds matches", desc: "Our engine scores every product for relevance, price fit, and popularity." },
              { icon: "🎁", step: "03", title: "Gift with confidence", desc: "Add to cart, checkout, done. Free returns on every order." },
            ].map((item) => (
              <div key={item.step} className="flex gap-4">
                <div className="shrink-0 flex h-10 w-10 items-center justify-center rounded-2xl bg-white border border-border/60 text-xl shadow-sm">
                  {item.icon}
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-widest text-givit-ember mb-1">{item.step}</p>
                  <p className="font-semibold text-sm text-foreground">{item.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured products */}
      {featured.length > 0 && (
        <section className="container py-8 md:py-10">
          <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="font-serif text-2xl font-bold text-foreground">Top Gift Picks</h2>
              <p className="text-muted-foreground mt-0.5 text-sm">Hand-curated by our AI engine this week</p>
            </div>
            <Link href="/products" className="givit-link text-sm font-medium">
              Shop all →
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
            {featured.slice(0, 6).map((p) => {
              const s = ratings[p.id];
              const avg = s?.avg_rating != null ? Number.parseFloat(String(s.avg_rating)) : null;
              return (
                <ProductCard
                  key={p.id}
                  product={p}
                  images={p.images}
                  avgRating={avg ?? undefined}
                  reviewCount={s?.review_count ?? 0}
                  compact
                  featured
                />
              );
            })}
          </div>
        </section>
      )}

      {/* Best sellers */}
      {bestSellers.length > 0 && (
        <section className="container py-6 md:py-8">
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3 border-b border-border/40 pb-3">
            <div>
              <h2 className="font-serif text-xl font-bold text-foreground md:text-2xl">Best Sellers</h2>
              <p className="text-muted-foreground mt-0.5 text-sm">Top-rated gifts buyers keep coming back for</p>
            </div>
            <Link href="/products?sort=popular" className="givit-link text-sm font-medium">See more →</Link>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {bestSellers.map((p) => {
              const s = ratings[p.id];
              const avg = s?.avg_rating != null ? Number.parseFloat(String(s.avg_rating)) : null;
              return (
                <ProductCard
                  key={p.id}
                  product={p}
                  images={p.images}
                  avgRating={avg ?? undefined}
                  reviewCount={s?.review_count ?? 0}
                  compact
                />
              );
            })}
          </div>
        </section>
      )}

      {/* New arrivals */}
      {newArrivals.length > 0 && (
        <section className="container py-6 md:py-8">
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3 border-b border-border/40 pb-3">
            <div>
              <h2 className="font-serif text-xl font-bold text-foreground md:text-2xl">New Arrivals</h2>
              <p className="text-muted-foreground mt-0.5 text-sm">Fresh listings from sellers this week</p>
            </div>
            <Link href="/products?sort=newest" className="givit-link text-sm font-medium">See more →</Link>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {newArrivals.map((p) => {
              const s = ratings[p.id];
              const avg = s?.avg_rating != null ? Number.parseFloat(String(s.avg_rating)) : null;
              return (
                <ProductCard
                  key={p.id}
                  product={p}
                  images={p.images}
                  avgRating={avg ?? undefined}
                  reviewCount={s?.review_count ?? 0}
                  compact
                />
              );
            })}
          </div>
        </section>
      )}

      {/* Empty state */}
      {featured.length === 0 && bestSellers.length === 0 && newArrivals.length === 0 && (
        <section className="container py-16 text-center">
          <div className="mx-auto max-w-md">
            <div className="mb-4 flex justify-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-3xl bg-givit-sand">
                <Gift className="h-7 w-7 text-givit-ember" />
              </div>
            </div>
            <h2 className="font-serif text-2xl font-bold mb-2">Ready for gifts</h2>
            <p className="text-muted-foreground text-sm mb-6">
              No products yet — seed your Supabase catalog to populate the storefront, or try the AI gift finder.
            </p>
            <Link
              href="/gift"
              className="inline-flex items-center gap-2 rounded-full bg-givit-ember px-6 py-2.5 text-sm font-semibold text-white hover:bg-givit-ember-hover transition-colors"
            >
              <Sparkles className="h-4 w-4" />
              Try the AI Gift Finder
            </Link>
          </div>
        </section>
      )}

      {/* CTA banner */}
      <section className="container mt-4">
        <div className="relative overflow-hidden rounded-3xl bg-givit-ember px-8 py-10 text-white md:px-12">
          <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/8" />
          <div className="pointer-events-none absolute -bottom-10 right-1/3 h-40 w-40 rounded-full bg-white/5" />
          <div className="relative">
            <p className="text-xs font-semibold uppercase tracking-widest text-white/60 mb-2">Sell on GIVIT</p>
            <h2 className="font-serif text-2xl font-bold md:text-3xl mb-2">
              Get your products in front of<br />the right gift-givers.
            </h2>
            <p className="text-white/70 text-sm mb-6 max-w-md">
              Join GIVIT as a seller. Your products get indexed by our AI engine and recommended to buyers at the exact moment they&apos;re looking for something like yours.
            </p>
            <Link
              href="/account/become-seller"
              className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-2.5 text-sm font-semibold text-givit-ember transition-colors hover:bg-white/90"
            >
              Become a Seller <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
