import Link from "next/link";
import { Gift, ShoppingCart, Sparkles } from "lucide-react";

import { HeaderProfileButton } from "@/components/layout/header-profile-button";
import { SiteHeaderShell } from "@/components/layout/site-header-shell";
import { SiteNavMenu } from "@/components/layout/site-nav-menu";
import { getCategories } from "@/lib/data/catalog";
import { createClient } from "@/lib/supabase/server";
import { Button } from "@/components/ui/button";
import type { UserRole } from "@/types/database";

type ProfileRow = {
  full_name: string | null;
  email: string;
  role: UserRole;
};

export async function SiteHeader() {
  const supabase = await createClient();
  const [categories, auth] = await Promise.all([
    getCategories(),
    supabase.auth.getUser(),
  ]);

  const user = auth.data.user;
  let profile: ProfileRow | null = null;

  if (user) {
    const { data } = await supabase
      .from("profiles")
      .select("full_name, email, role")
      .eq("id", user.id)
      .single();
    if (data) profile = data as ProfileRow;
  }

  const isSeller = profile?.role === "staff" || profile?.role === "admin";
  const cartHref = user ? "/cart" : "/login?next=/cart";

  return (
    <SiteHeaderShell>
      <div className="bg-givit-ink text-white">
        <div className="container flex items-center gap-3 py-3 md:gap-4">
          {/* Logo */}
          <Link href="/" className="shrink-0 flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-givit-ember">
              <Gift className="h-4 w-4 text-white" />
            </div>
            <span className="font-serif text-xl font-bold tracking-tight hidden sm:block">
              GIV<span className="text-givit-coral">IT</span>
            </span>
          </Link>

          {/* AI Search / nav link */}
          <Link
            href="/gift"
            className="flex-1 max-w-xl group"
          >
            <div className="flex items-center gap-2 rounded-full bg-white/10 border border-white/10 px-4 py-2 text-sm text-white/60 transition-all group-hover:bg-white/15 group-hover:text-white/80 group-hover:border-white/20">
              <Sparkles className="h-4 w-4 text-givit-coral shrink-0" />
              <span>Gift for mom under $50, eco-friendly...</span>
            </div>
          </Link>

          {/* Right actions */}
          <div className="flex shrink-0 items-center gap-1 sm:gap-2">
            <Link
              href="/products"
              className="hidden rounded-full px-3 py-2 text-sm font-medium transition-colors hover:bg-white/10 md:block"
            >
              Browse
            </Link>

            <Link
              href={cartHref}
              aria-label="Cart"
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-white/10"
            >
              <ShoppingCart className="h-5 w-5" />
            </Link>

            <HeaderProfileButton
              loggedIn={Boolean(user && profile)}
              email={profile?.email}
              displayName={profile?.full_name ?? undefined}
              role={profile?.role}
            />

            {isSeller ? (
              <Button
                asChild
                size="sm"
                className="hidden h-8 rounded-full bg-givit-ember px-3 text-xs font-semibold text-white hover:bg-givit-ember-hover lg:inline-flex"
              >
                <Link href="/admin">Seller Console</Link>
              </Button>
            ) : null}

            {profile?.role === "admin" ? (
              <Button
                asChild
                size="sm"
                variant="outline"
                className="hidden h-8 rounded-full border-white/20 bg-transparent px-3 text-xs font-semibold text-white hover:bg-white/10 lg:inline-flex"
              >
                <Link href="/manager">Manager</Link>
              </Button>
            ) : null}

            <SiteNavMenu
              categories={categories.map((c) => ({ id: c.id, name: c.name, slug: c.slug }))}
              isSeller={isSeller}
            />
          </div>
        </div>

        {/* Category bar — subtle secondary bar */}
        <div className="border-t border-white/8 bg-white/5">
          <div className="container flex items-center gap-1 overflow-x-auto py-1.5 scrollbar-none">
            {categories.map((cat) => (
              <Link
                key={cat.id}
                href={`/products?category=${cat.slug}`}
                className="shrink-0 rounded-full px-3 py-1 text-xs font-medium text-white/60 transition-colors hover:bg-white/10 hover:text-white whitespace-nowrap"
              >
                {cat.name}
              </Link>
            ))}
            <Link
              href="/gift"
              className="shrink-0 ml-auto flex items-center gap-1 rounded-full bg-givit-ember/20 border border-givit-coral/30 px-3 py-1 text-xs font-semibold text-givit-coral transition-colors hover:bg-givit-ember/30 whitespace-nowrap"
            >
              <Sparkles className="h-3 w-3" />
              AI Finder
            </Link>
          </div>
        </div>
      </div>
    </SiteHeaderShell>
  );
}
